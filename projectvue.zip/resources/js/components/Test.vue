<template>

</template>

<script>
export default {
  props: {
    test: {
      type: String,
      default: null,
    },
  },
}
</script>
