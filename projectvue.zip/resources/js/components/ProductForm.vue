<template>
<div>
  <div class="form-group">
    <el-form-item label="Name">
      <el-input placeholder="Enter Name" type="text" v-model="product.name"></el-input>
    </el-form-item>
  </div>
  <div class="form-group">
    <el-form-item label="Price">
      <el-input placeholder="Enter Price" type="text" v-model="product.price"></el-input>
    </el-form-item>
  </div>
</div>
</template>

<script>
export default {
  props: {
    product: {
      type: Object,
      default: {},
    },
  }
}
</script>
