<template>
<div>
  <span class="title h4">Homepage <br>Laravel Project with Vue 3, Auth (Sanctum), CURD Example</span>
</div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {
      //
    }
  },
  created() {},
  methods: {}
}
</script>

<style lang="scss" scoped>
.title {
  margin-left: 10px !important;
  margin-top: 25px !important;
}
</style>
